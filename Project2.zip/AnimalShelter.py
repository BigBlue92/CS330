# Ryan Mackenzie
# CS340-T1036
# Project 1: CRUD in Python
# AnimalShelter.py is a class to define MongoDB CRUD operations that can be called by a Python script.

from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):

    """ CRUD operations for Animal collection in MongoDB """

 

    def __init__(self, username=None, password=None):

        # Initializing the MongoClient. This helps to 

        # access the MongoDB databases and collections. 
        self.client = MongoClient('mongodb://%s:%s@localhost:37653/AAC' % (username, password))
        self.database = self.client['AAC']
        
        
    # Create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            insert = self.database.animals.insert(data)  # data should be dictionary 
            if insert!=0:
                return True
            else:
                return False           
        else:
            raise Exception("Nothing to save, no parameter.")


    # Create method to implement the R in CRUD.
    def read(self,criteria=None):

        # Criteria is not none then return all rows which match
        if criteria:       
            
            data = self.database.animals.find(criteria)
        else:
        # If no search criteria, return all rows 
            data = self.database.animals.find( {} , {"_id":False})

        return data

    # this create method to implement the U in CRUD

    def update(self, filter, newData):

        if newData is not None:

            updated = self.database.animals.update_many(filter, newData)

        else:
            raise Exception("Nothing to update, because data parameter is empty")
            
    # The method to implement the D in CRUD.
    def delete(self, data):
        if data is not None:
            if data:
                removeResult = self.database.animals.delete_one(data)
        else:
            exception: "Nothing to delete, record does not exist."